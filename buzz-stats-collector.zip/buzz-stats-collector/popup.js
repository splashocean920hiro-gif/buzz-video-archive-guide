function $(id) { return document.getElementById(id); }

async function loadSettings() {
  const settings = await chrome.runtime.sendMessage({ cmd: 'getSettings' });
  $('archiveUrl').value = settings.archiveUrl || '';
  $('ingestKey').value = settings.ingestKey || '';
  $('viewThreshold').value = settings.viewThreshold || 20000;
  $('maxAgeMonths').value = settings.maxAgeMonths != null ? settings.maxAgeMonths : 6;
  $('keywords').value = (settings.keywords || []).join('\n');
}

function parseKeywords() {
  // 1行=1エントリ。行内にスペースが無ければ単体ハッシュタグ、あれば複合キーワード検索として扱う
  // （background.js側でスペースの有無を見て遷移先URLを振り分ける）
  return $('keywords').value.split(/[\n\r]+/).map((s) => s.trim().replace(/^#/, '')).filter(Boolean);
}

function labelForStatus(s) {
  return {
    idle: '待機中', running: '実行中', paused: '一時停止（要確認）', completed: '✅ リサーチ完了',
    session_cooldown: '⏳ セッション上限（自動待機中）', daily_limit: '🌙 本日の上限に到達',
  }[s] || s;
}

function labelForMode(m) {
  return { discover: 'バズ動画発見', backfill: 'フォロワー数バックフィル' }[m] || '-';
}

function fmtRemaining(ms) {
  if (ms <= 0) return 'まもなく';
  const totalMin = Math.ceil(ms / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return h > 0 ? `${h}時間${m}分後` : `${m}分後`;
}

async function refreshStatus() {
  const state = await chrome.runtime.sendMessage({ cmd: 'getStatus' });
  let detail = '';
  if (state.mode === 'discover') {
    const settings = await chrome.runtime.sendMessage({ cmd: 'getSettings' });
    const keywords = settings.keywords || [];
    const currentKeyword = keywords[(state.keywordIndex || 0) % keywords.length];
    const activeKeyword = keywords.length ? (currentKeyword.includes(' ') ? `検索:${currentKeyword}` : `#${currentKeyword}`) : '/explore/おすすめ';
    detail = `対象: ${activeKeyword} ・ 候補キュー: ${state.candidates ? state.candidates.length : 0}件 ・ 処理済み: ${state.processed ? state.processed.length : 0}件`;
  } else if (state.mode === 'backfill') {
    const total = state.queue ? state.queue.length : 0;
    detail = `進捗: ${state.index || 0} / ${total}`;
  }
  let capNote = '';
  if (state.status === 'session_cooldown' && state.cooldownUntil) {
    capNote = `<br>⏳ 次のセッションまで: ${fmtRemaining(state.cooldownUntil - Date.now())}`;
  } else if (state.status === 'daily_limit') {
    capNote = `<br>🌙 本日はここまでです。日付が変わったら「🔍 バズ動画発見を開始」で再開してください。`;
  }

  $('status').innerHTML = `
    モード: <b>${labelForMode(state.mode)}</b> ・ 状態: <b>${labelForStatus(state.status)}</b><br>
    ${detail}<br>
    セッション: ${state.sessionCount || 0}件 ・ 本日: ${state.dailyCount || 0}件${capNote}
  `;
  $('pausedActions').style.display = state.status === 'paused' ? 'flex' : 'none';
  $('completedBanner').style.display = state.status === 'completed' ? 'block' : 'none';

  const log = (state.log || []).slice(-8).reverse();
  $('log').innerHTML = log.map((e) => {
    const mark = e.ok ? '✅' : '⚠️';
    const detailText = e.ok
      ? `${e.username ? '@' + e.username + ' ' : ''}👤${e.value != null ? e.value.toLocaleString() : ''}${e.viewCount ? ' ▶' + e.viewCount.toLocaleString() : ''}`
      : (e.reason || e.error || '');
    return `<div>${mark} ${e.key || ''}: ${detailText}</div>`;
  }).join('');
}

$('saveBtn').onclick = async () => {
  await chrome.runtime.sendMessage({
    cmd: 'saveSettings',
    settings: {
      archiveUrl: $('archiveUrl').value.trim().replace(/\/$/, ''),
      ingestKey: $('ingestKey').value.trim(),
      viewThreshold: parseInt($('viewThreshold').value, 10) || 20000,
      maxAgeMonths: parseInt($('maxAgeMonths').value, 10) || 0,
      keywords: parseKeywords(),
    },
  });
  $('saveBtn').textContent = '💾 保存しました';
  setTimeout(() => { $('saveBtn').textContent = '💾 設定を保存'; }, 1500);
};

$('randomKeywordsBtn').onclick = async () => {
  $('randomKeywordsBtn').disabled = true;
  $('randomKeywordsBtn').textContent = '選出中…';
  const res = await chrome.runtime.sendMessage({ cmd: 'getRandomKeywords', count: 3 });
  $('randomKeywordsBtn').disabled = false;
  $('randomKeywordsBtn').textContent = '🎲 ランダムでキーワードを選出';
  if (!res.ok) {
    alert(res.error);
    return;
  }
  $('keywords').value = res.keywords.join('\n');
  await chrome.runtime.sendMessage({ cmd: 'saveSettings', settings: { keywords: res.keywords } });
};

$('startDiscover').onclick = async () => {
  const threshold = parseInt($('viewThreshold').value, 10) || 20000;
  const maxAgeMonths = parseInt($('maxAgeMonths').value, 10) || 0;
  const keywords = parseKeywords();
  await chrome.runtime.sendMessage({ cmd: 'saveSettings', settings: { viewThreshold: threshold, maxAgeMonths, keywords } });
  const res = await chrome.runtime.sendMessage({ cmd: 'startDiscover', threshold });
  if (!res.ok) alert(res.error);
  refreshStatus();
};

$('startBackfill').onclick = async () => {
  const res = await chrome.runtime.sendMessage({ cmd: 'startBackfill' });
  if (!res.ok) alert(res.error);
  refreshStatus();
};

$('stopBtn').onclick = async () => {
  await chrome.runtime.sendMessage({ cmd: 'stop' });
  refreshStatus();
};
$('resetProcessedBtn').onclick = async () => {
  if (!confirm('処理済みリストをリセットします。アーカイブ側を削除済みの場合など、同じ動画を再度発見・収集できるようになります。よろしいですか？')) return;
  await chrome.runtime.sendMessage({ cmd: 'resetProcessed' });
  refreshStatus();
};
$('resumeBtn').onclick = async () => {
  await chrome.runtime.sendMessage({ cmd: 'resume' });
  refreshStatus();
};
$('resumeAlwaysBtn').onclick = async () => {
  await chrome.runtime.sendMessage({ cmd: 'resume' });
  refreshStatus();
};
$('skipBtn').onclick = async () => {
  await chrome.runtime.sendMessage({ cmd: 'skip' });
  refreshStatus();
};

$('settingsToggle').onclick = () => {
  const panel = $('settingsPanel');
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
};

loadSettings();
refreshStatus();
setInterval(refreshStatus, 1500);
