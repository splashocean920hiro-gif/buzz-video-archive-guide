const DEFAULTS = {
  archiveUrl: 'https://buzz-video-archive-production.up.railway.app',
  ingestKey: '',
  sessionCap: 25,
  dailyCap: 80,
  sessionCooldownMinutes: 120, // セッション上限に達してから自動で次のセッションを始めるまでの待機時間
  viewThreshold: 20000,
  maxAgeMonths: 6,
  keywords: [],
  minDelayMs: 8000,
  maxDelayMs: 20000,
  longPauseChance: 0.15,
  longPauseMinMs: 30000,
  longPauseMaxMs: 60000,
};

const EMPTY_STATE = {
  status: 'idle', // idle | running | paused | completed | session_cooldown | daily_limit
  mode: null, // 'discover' | 'backfill'
  tabId: null,
  sessionCount: 0,
  dailyCount: 0,
  dailyDate: null,
  cooldownUntil: null, // session_cooldown中: 次のセッションを自動開始する時刻(ms)
  log: [],

  // backfill（フォロワー数のみ。再生数の単体バックフィルは実機検証の結果不可能と判明したため廃止）
  queue: [],
  index: 0,

  // discover（/explore/ または /explore/tags/xxx/ 発見型）
  candidates: [], // 未処理の {shortcode, url, viewCount}
  current: null,  // 処理中の候補
  processed: [],  // 処理済みshortcode（重複防止・直近500件）
  keywordIndex: 0, // settings.keywords の何番目を巡回中か
  lapNewCount: 0, // キーワードリストを1周する間に見つかった新規候補数（0のまま1周したら「完了」とみなす）
  recentKeywords: [], // ランダム抽出で直近選ばれたキーワード（同じものが連続で選ばれにくくする）
};

async function getSettings() {
  const stored = await chrome.storage.local.get(['settings']);
  return { ...DEFAULTS, ...(stored.settings || {}) };
}

async function saveSettings(patch) {
  const current = await getSettings();
  await chrome.storage.local.set({ settings: { ...current, ...patch } });
}

async function getState() {
  const stored = await chrome.storage.local.get(['state']);
  return { ...EMPTY_STATE, ...(stored.state || {}) };
}

async function setState(patch) {
  const state = await getState();
  const next = { ...state, ...patch };
  await chrome.storage.local.set({ state: next });
  return next;
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function randomDelay(min, max) {
  return Math.floor(min + Math.random() * (max - min));
}

async function resetDailyIfNeeded() {
  const state = await getState();
  if (state.dailyDate !== todayStr()) {
    await setState({ dailyDate: todayStr(), dailyCount: 0 });
  }
}

async function fetchArchive(settings, path, method, body) {
  const res = await fetch(`${settings.archiveUrl}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Ingest-Key': settings.ingestKey },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`${path} 失敗: HTTP ${res.status} ${text}`.trim());
  }
  return res.json().catch(() => ({}));
}

function pushLog(state, entry) {
  return [...(state.log || []), entry].slice(-100);
}

// ---------- タブ操作 ----------
async function navigateTab(url) {
  const state = await getState();
  if (state.tabId) {
    try {
      await chrome.tabs.update(state.tabId, { url });
      return;
    } catch (e) { /* タブが閉じられていた等 → 新規タブへ */ }
  }
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (active) {
    await chrome.tabs.update(active.id, { url });
    await setState({ tabId: active.id });
  } else {
    const created = await chrome.tabs.create({ url });
    await setState({ tabId: created.id });
  }
}

function isDiscoveryHomePath(path) {
  // Instagramは /explore/tags/xxx/ を開いても実際には /explore/search/keyword/?q=... に
  // 遷移することがあるため、両方のパス形式を「発見ページ」として認識する。
  return path === '/explore/' || path === '/explore'
    || path === '/explore/search/keyword/' || path === '/explore/search/keyword'
    || /^\/explore\/tags\/[^/]+\/?$/.test(path);
}

function notifyResearchComplete(keywords) {
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icon.png'),
      title: '🔥 バズ動画発見 完了',
      message: `設定したキーワード（${keywords.join('、')}）でリサーチした全リストのアーカイブが完了しました。キーワードを変更してください。`,
      priority: 2,
    });
  } catch (e) { /* 通知が使えない環境でも本体機能には影響させない */ }
}

// キーワードが設定されていれば /explore/tags/{keyword}/ を順番に巡回、無ければ /explore/ を使う。
// advanceKeyword=true で次のキーワードへローテーションする（候補を使い切った時に呼ぶ）。
// キーワードリストを1周する間ずっと新規候補が0件だったら「完了」とみなして自動停止・通知する。
async function navigateToDiscoveryHome(advanceKeyword) {
  const settings = await getSettings();
  const keywords = (settings.keywords || []).filter(Boolean);
  if (keywords.length === 0) {
    await navigateTab('https://www.instagram.com/explore/');
    return;
  }
  const state = await getState();
  let idx = state.keywordIndex || 0;
  let lapNewCount = state.lapNewCount || 0;
  if (advanceKeyword) {
    idx = (idx + 1) % keywords.length;
    if (idx === 0) {
      if (lapNewCount === 0) {
        await setState({ status: 'completed', keywordIndex: 0, lapNewCount: 0 });
        notifyResearchComplete(keywords);
        return;
      }
      lapNewCount = 0; // 新規が見つかったので次の周回をカウントし直す
    }
  }
  await setState({ keywordIndex: idx, lapNewCount });
  const keyword = keywords[idx % keywords.length];
  await navigateTab(keywordToUrl(keyword));
}

// スペースを含む場合は単体ハッシュタグとして解決できないため、複合キーワード検索に回す
// （例:「Threads AI」のように2語以上でAI関連に絞り込みたい時用）。
function keywordToUrl(keyword) {
  if (/\s/.test(keyword.trim())) {
    return `https://www.instagram.com/explore/search/keyword/?q=${encodeURIComponent(keyword.trim())}`;
  }
  return `https://www.instagram.com/explore/tags/${encodeURIComponent(keyword)}/`;
}

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await getState();
  if (state.tabId === tabId && state.status === 'running') {
    await setState({ status: 'paused', tabId: null });
  }
});

// ---------- discoverモード（/explore/ 発見型） ----------
async function startDiscover(threshold) {
  await resetDailyIfNeeded();
  if (threshold) await saveSettings({ viewThreshold: threshold });
  chrome.alarms.clear('buzz-session-cooldown');
  await setState({
    status: 'running', mode: 'discover',
    candidates: [], current: null, sessionCount: 0, tabId: null, log: [], keywordIndex: 0, lapNewCount: 0,
    cooldownUntil: null,
  });
  await navigateToDiscoveryHome(false);
}

async function advanceDiscover() {
  const state = await getState();
  if (state.candidates.length > 0) {
    const [next, ...rest] = state.candidates;
    await setState({ current: next, candidates: rest });
    await navigateTab(next.url);
  } else {
    await navigateToDiscoveryHome(true);
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'buzz-session-cooldown') {
    const state = await getState();
    if (state.status !== 'session_cooldown') return; // 待機中に手動停止等されていたら何もしない
    await setState({ status: 'running', sessionCount: 0, cooldownUntil: null });
    await advanceDiscover();
    return;
  }
  const state = await getState();
  if (state.status !== 'running') return;
  if (alarm.name === 'buzz-discover-next') {
    await advanceDiscover();
  } else if (alarm.name === 'buzz-backfill-next') {
    await navigateCurrentBackfill();
  }
});

function scheduleNext(alarmName, settings) {
  const useLongPause = Math.random() < settings.longPauseChance;
  const delay = useLongPause
    ? randomDelay(settings.longPauseMinMs, settings.longPauseMaxMs)
    : randomDelay(settings.minDelayMs, settings.maxDelayMs);
  chrome.alarms.create(alarmName, { when: Date.now() + delay });
}

// 1件処理し終えた直後に呼ぶ: 日次上限→session_cooldown（自動再開待ち）→通常続行、の優先順で判定する
async function handleCapsOrScheduleNext(settings, dailyCount, sessionCount, alarmName) {
  if (dailyCount >= settings.dailyCap) {
    await setState({ status: 'daily_limit', cooldownUntil: null });
  } else if (sessionCount >= settings.sessionCap) {
    const cooldownUntil = Date.now() + settings.sessionCooldownMinutes * 60 * 1000;
    await setState({ status: 'session_cooldown', cooldownUntil });
    chrome.alarms.create('buzz-session-cooldown', { when: cooldownUntil });
  } else {
    scheduleNext(alarmName, settings);
  }
}

// ---------- ランダムキーワード抽出（保管庫の共有プールから） ----------
async function fetchKeywordPool() {
  const settings = await getSettings();
  if (!settings.ingestKey) throw new Error('Ingestキーが未設定です（ポップアップから設定してください）');
  const res = await fetch(`${settings.archiveUrl}/api/keywords`, {
    headers: { 'X-Ingest-Key': settings.ingestKey },
  });
  if (!res.ok) throw new Error(`キーワード取得失敗: HTTP ${res.status}`);
  return res.json();
}

function pickRandomKeywords(pool, count, exclude) {
  const excludeSet = new Set(exclude || []);
  let candidates = pool.filter((k) => !excludeSet.has(k));
  if (candidates.length < count) candidates = pool.slice(); // 除外すると母数が足りない場合は諦めて全体から選ぶ
  const shuffled = candidates.slice().sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

// ---------- backfillモード（フォロワー数のみ） ----------
async function fetchPendingProfiles() {
  const settings = await getSettings();
  if (!settings.ingestKey) throw new Error('Ingestキーが未設定です（ポップアップから設定してください）');
  const res = await fetch(`${settings.archiveUrl}/api/admin/pending_stats?type=profile&limit=30`, {
    headers: { 'X-Ingest-Key': settings.ingestKey },
  });
  if (!res.ok) throw new Error(`キュー取得失敗: HTTP ${res.status}`);
  return res.json();
}

async function startBackfill() {
  await resetDailyIfNeeded();
  const items = await fetchPendingProfiles();
  await setState({
    status: items.length ? 'running' : 'idle', mode: 'backfill',
    queue: items, index: 0, sessionCount: 0, tabId: null, log: [],
  });
  if (items.length) await navigateCurrentBackfill();
  return items.length;
}

async function navigateCurrentBackfill() {
  const state = await getState();
  const item = state.queue[state.index];
  if (!item) {
    await setState({ status: 'idle' });
    return;
  }
  await navigateTab(item.profile_url);
}

// ---------- メッセージハンドラ ----------
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.cmd) {
      case 'getStatus':
        sendResponse(await getState());
        break;

      case 'getSettings':
        sendResponse(await getSettings());
        break;

      case 'saveSettings':
        await saveSettings(msg.settings);
        sendResponse({ ok: true });
        break;

      case 'startDiscover':
        try {
          await startDiscover(msg.threshold);
          sendResponse({ ok: true });
        } catch (e) {
          sendResponse({ ok: false, error: String(e.message || e) });
        }
        break;

      case 'startBackfill':
        try {
          const count = await startBackfill();
          sendResponse({ ok: true, count });
        } catch (e) {
          sendResponse({ ok: false, error: String(e.message || e) });
        }
        break;

      case 'stop':
        chrome.alarms.clear('buzz-discover-next');
        chrome.alarms.clear('buzz-backfill-next');
        chrome.alarms.clear('buzz-session-cooldown');
        await setState({ status: 'idle', cooldownUntil: null });
        sendResponse({ ok: true });
        break;

      case 'resetProcessed':
        await setState({ processed: [] });
        sendResponse({ ok: true });
        break;

      case 'getRandomKeywords':
        try {
          const pool = await fetchKeywordPool();
          if (!pool.length) throw new Error('キーワード候補が保管庫に登録されていません（管理者ページの「🎲 キーワード管理」から追加してください）');
          const state = await getState();
          const count = msg.count || 3;
          const picked = pickRandomKeywords(pool, count, state.recentKeywords);
          const recentKeywords = [...(state.recentKeywords || []), ...picked].slice(-15);
          await setState({ recentKeywords });
          sendResponse({ ok: true, keywords: picked });
        } catch (e) {
          sendResponse({ ok: false, error: String(e.message || e) });
        }
        break;

      case 'resume': {
        const prev = await getState();
        const patch = { status: 'running' };
        if (prev.status === 'session_cooldown') {
          // 待たずに手動再開する場合は、新しいセッションとして数え直す
          patch.sessionCount = 0;
          patch.cooldownUntil = null;
          chrome.alarms.clear('buzz-session-cooldown');
        }
        const state = await setState(patch);
        if (state.mode === 'discover') {
          if (state.current) await navigateTab(state.current.url);
          else await advanceDiscover();
        } else if (state.mode === 'backfill') {
          await navigateCurrentBackfill();
        }
        sendResponse({ ok: true });
        break;
      }

      case 'skip': {
        const state = await getState();
        if (state.mode === 'discover') {
          await setState({ status: 'running', current: null });
          await advanceDiscover();
        } else if (state.mode === 'backfill') {
          await setState({ status: 'running', index: state.index + 1 });
          await navigateCurrentBackfill();
        }
        sendResponse({ ok: true });
        break;
      }

      case 'checkActive': {
        const state = await getState();
        if (state.status !== 'running') { sendResponse({ active: false }); break; }

        if (state.mode === 'discover') {
          const path = msg.path || '';
          if (isDiscoveryHomePath(path)) {
            const settings = await getSettings();
            sendResponse({
              active: true, mode: 'discover', phase: 'explore',
              threshold: settings.viewThreshold, maxAgeMonths: settings.maxAgeMonths, alreadyProcessed: state.processed,
            });
          } else if (state.current) {
            sendResponse({ active: true, mode: 'discover', phase: 'post', current: state.current });
          } else {
            sendResponse({ active: false });
          }
        } else if (state.mode === 'backfill') {
          const item = state.queue[state.index];
          if (!item) { sendResponse({ active: false }); break; }
          sendResponse({ active: true, mode: 'backfill', queueType: 'profile', item });
        } else {
          sendResponse({ active: false });
        }
        break;
      }

      case 'exploreCandidates': {
        const state = await getState();
        const seen = new Set([
          ...(state.processed || []),
          ...(state.candidates || []).map((c) => c.shortcode),
          state.current ? state.current.shortcode : null,
        ].filter(Boolean));
        const fresh = (msg.candidates || []).filter((c) => !seen.has(c.shortcode));
        const candidates = [...(state.candidates || []), ...fresh];
        const lapNewCount = (state.lapNewCount || 0) + fresh.length;
        await setState({ candidates, lapNewCount });
        const latest = await getState();
        if (!latest.current && latest.status === 'running') {
          await advanceDiscover();
        }
        sendResponse({ ok: true });
        break;
      }

      case 'profileResult': {
        const settings = await getSettings();
        const state = await getState();
        const current = state.current;
        try {
          if (!current || current.shortcode !== msg.shortcode) throw new Error('状態が一致しません（キューが進んでいる可能性）');
          if (!settings.ingestKey) throw new Error('Ingestキーが未設定です');

          await fetchArchive(settings, '/ingest', 'POST', {
            url: current.url, uploader: msg.username, thumbnail: msg.thumbnail || '', caption: msg.caption || '',
            posted_at: current.postedAt || '',
          });
          await fetchArchive(settings, '/api/stats/video', 'POST', { shortcode: current.shortcode, view_count: current.viewCount });
          await fetchArchive(settings, '/api/stats/profile', 'POST', { username: msg.username, follower_count: msg.followerCount });

          const processed = [...(state.processed || []), current.shortcode].slice(-500);
          const sessionCount = state.sessionCount + 1;
          const dailyCount = state.dailyCount + 1;
          const log = pushLog(state, {
            time: Date.now(), kind: 'discover', key: current.shortcode,
            value: msg.followerCount, viewCount: current.viewCount, username: msg.username, ok: true,
          });
          const updated = await setState({ processed, sessionCount, dailyCount, current: null, log });

          if (updated.status !== 'running') {
            // 処理中に「停止」が押されていたら、次のページ予約はしない
          } else {
            await handleCapsOrScheduleNext(settings, dailyCount, sessionCount, 'buzz-discover-next');
          }
          sendResponse({ ok: true });
        } catch (e) {
          const log = pushLog(state, { time: Date.now(), kind: 'discover', key: msg.shortcode, error: String(e.message || e), ok: false });
          await setState({ status: 'paused', log });
          sendResponse({ ok: false, error: String(e.message || e) });
        }
        break;
      }

      case 'profileAnomaly': {
        const state = await getState();
        const log = pushLog(state, { time: Date.now(), kind: 'discover', key: msg.shortcode, reason: msg.reason, ok: false });
        await setState({ status: 'paused', log });
        sendResponse({ ok: true });
        break;
      }

      case 'reportResult': {
        // backfill(フォロワー)専用
        const settings = await getSettings();
        const state = await getState();
        try {
          if (!settings.ingestKey) throw new Error('Ingestキーが未設定です');
          await fetchArchive(settings, '/api/stats/profile', 'POST', { username: msg.username, follower_count: msg.value });

          const sessionCount = state.sessionCount + 1;
          const dailyCount = state.dailyCount + 1;
          const index = state.index + 1;
          const log = pushLog(state, { time: Date.now(), kind: 'profile', key: msg.username, value: msg.value, ok: true });
          const next = await setState({ sessionCount, dailyCount, index, log });

          if (index >= next.queue.length) {
            await setState({ status: 'idle' });
          } else {
            await handleCapsOrScheduleNext(settings, dailyCount, sessionCount, 'buzz-backfill-next');
          }
          sendResponse({ ok: true });
        } catch (e) {
          const log = pushLog(state, { time: Date.now(), kind: 'profile', key: msg.username, error: String(e.message || e), ok: false });
          await setState({ status: 'paused', log });
          sendResponse({ ok: false, error: String(e.message || e) });
        }
        break;
      }

      case 'reportAnomaly': {
        const state = await getState();
        const log = pushLog(state, { time: Date.now(), kind: 'profile', key: msg.key, reason: msg.reason, ok: false });
        await setState({ status: 'paused', log });
        sendResponse({ ok: true });
        break;
      }

      default:
        sendResponse({ ok: false, error: 'unknown cmd' });
    }
  })();
  return true;
});
