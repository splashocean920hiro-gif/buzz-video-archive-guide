function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
function randInt(min, max) { return Math.floor(min + Math.random() * (max - min)); }

function getShortcodeFromHref(href) {
  const m = (href || '').match(/\/(?:p|reel|reels)\/([A-Za-z0-9_-]+)/);
  return m ? m[1] : null;
}

const RESERVED_PATH_SEGMENTS = new Set([
  'p', 'reel', 'reels', 'explore', 'accounts', 'stories', 'direct', 'about',
  'developer', 'legal', 'privacy', 'api', 'web', 'tv', 'lite', 'ads', 'help',
  'emails', 'sessions', 'challenge', 'settings', 'nametag', 'topics',
]);

function getUsernameFromProfileUrl(url) {
  const u = new URL(url);
  const seg = u.pathname.split('/').filter(Boolean);
  if (seg.length === 1 && !RESERVED_PATH_SEGMENTS.has(seg[0])) return seg[0];
  return null;
}

function parseCount(raw) {
  if (raw == null) return null;
  const s = String(raw).trim().replace(/,/g, '');
  let m = s.match(/^([\d.]+)\s*万$/);
  if (m) return Math.round(parseFloat(m[1]) * 10000);
  m = s.match(/^([\d.]+)\s*億$/);
  if (m) return Math.round(parseFloat(m[1]) * 100000000);
  m = s.match(/^([\d.]+)\s*[Kk]$/);
  if (m) return Math.round(parseFloat(m[1]) * 1000);
  m = s.match(/^([\d.]+)\s*[Mm]$/);
  if (m) return Math.round(parseFloat(m[1]) * 1000000);
  m = s.match(/^([\d.]+)\s*[Bb]$/);
  if (m) return Math.round(parseFloat(m[1]) * 1000000000);
  if (/^\d+$/.test(s)) return parseInt(s, 10);
  return null;
}

// 実機検証済み: プロフィールホバーカード/プロフィールページ双方で「1.1万\nフォロワー」形式で出現する
const FOLLOWER_PATTERN = /([\d,.]+\s*万?)\s*\n?\s*(?:人の)?フォロワー|([\d,.]+\s*[KMkm]?)\s*[Ff]ollowers?/;

function parseFollowerMatch(text) {
  const m = text.match(FOLLOWER_PATTERN);
  if (!m) return null;
  const raw = (m[1] || m[2] || '').trim();
  const value = parseCount(raw.replace(/\s/g, ''));
  return value != null ? { value, raw } : null;
}

function createOverlay() {
  const host = document.createElement('div');
  host.id = 'buzz-stats-overlay-host';
  host.style.cssText = 'all:initial;position:fixed;bottom:16px;right:16px;z-index:2147483647;';
  const shadow = host.attachShadow({ mode: 'open' });
  const style = document.createElement('style');
  style.textContent = `
    .box { font-family: -apple-system, BlinkMacSystemFont, sans-serif; background:#2b2b2b; color:#fff;
      border-radius:10px; padding:12px 14px; width:260px; box-shadow:0 4px 16px rgba(0,0,0,.45); font-size:13px; line-height:1.6; }
    .box.anomaly { background:#7a2e2e; }
    .row { margin-bottom:6px; }
    button { font-size:12px; padding:6px 10px; border-radius:6px; border:none; cursor:pointer; margin-right:6px; }
    .btn-secondary { background:#555; color:#fff; }
    .small { font-size:11px; opacity:.75; }
  `;
  shadow.appendChild(style);
  const box = document.createElement('div');
  box.className = 'box';
  shadow.appendChild(box);
  document.documentElement.appendChild(host);
  return { host, box };
}

function removeOverlayLater(host, ms) {
  setTimeout(() => host.remove(), ms);
}

// 検出失敗時のスキップボタン。指定秒数クリックが無ければ自動でスキップして再開する。
function setupSkipButton(box, host, seconds) {
  const btn = box.querySelector('#buzz-skip');
  const countdownEl = box.querySelector('#buzz-countdown');
  let remaining = seconds;
  let done = false;
  const finish = async () => {
    if (done) return;
    done = true;
    clearInterval(timer);
    try { await chrome.runtime.sendMessage({ cmd: 'skip' }); } catch (e) { /* ignore */ }
    host.remove();
  };
  const timer = setInterval(() => {
    remaining -= 1;
    if (countdownEl) countdownEl.textContent = `${remaining}秒後に自動スキップ`;
    if (remaining <= 0) finish();
  }, 1000);
  btn.onclick = finish;
}

// ---------- /explore/ ページ: IG Sorterのグリッドからバズ候補を発見 ----------
// 実機検証済みDOM構造: <a href="/p/{shortcode}/"> の中に class に "ndy_ins_info" を含む
// IG Sorterのオーバーレイdivがあり、innerTextは
// "IG Sorter\nいいね数\nコメント数\nリポスト数\n日付(YYYY-MM-DD)\n再生数\nER x.xx%" の順で並ぶ
function scanExploreTiles(cutoffDate) {
  const tiles = Array.from(document.querySelectorAll('a[href^="/p/"], a[href^="/reel/"], a[href^="/reels/"]'));
  const results = [];
  for (const a of tiles) {
    const shortcode = getShortcodeFromHref(a.getAttribute('href'));
    if (!shortcode) continue;
    const overlay = a.querySelector('[class*="ndy_ins_info"]');
    if (!overlay) continue; // IG Sorter未導入 or まだ計算中
    const lines = overlay.innerText.trim().split('\n');
    if (lines.length < 4) continue;
    const erLine = lines[lines.length - 1];
    const viewLine = lines[lines.length - 2];
    const dateLine = lines[lines.length - 3];
    if (!/^ER/.test(erLine) || !/^[\d,]+$/.test(viewLine)) continue;
    const viewCount = parseInt(viewLine.replace(/,/g, ''), 10);
    if (!viewCount) continue;
    if (cutoffDate) {
      const postDate = new Date(dateLine);
      if (!isNaN(postDate) && postDate < cutoffDate) continue; // 指定期間より古い投稿は除外
    }
    results.push({
      shortcode,
      url: `https://www.instagram.com${a.getAttribute('href')}`,
      viewCount,
      postedAt: /^\d{4}-\d{2}-\d{2}$/.test(dateLine) ? dateLine : '',
    });
  }
  return results;
}

async function runExploreDiscovery(threshold, alreadyProcessed, maxAgeMonths) {
  const seen = new Set(alreadyProcessed || []);
  const found = new Map();
  let cutoffDate = null;
  if (maxAgeMonths) {
    cutoffDate = new Date();
    cutoffDate.setMonth(cutoffDate.getMonth() - maxAgeMonths);
  }

  for (let i = 0; i < 5; i++) {
    await sleep(randInt(1500, 3000));
    window.scrollBy({ top: randInt(400, 900), behavior: 'smooth' });
    await sleep(randInt(2000, 3500));

    const tiles = scanExploreTiles(cutoffDate);
    for (const t of tiles) {
      if (seen.has(t.shortcode) || found.has(t.shortcode)) continue;
      if (t.viewCount >= threshold) found.set(t.shortcode, t);
    }
    if (found.size >= 5) break;
  }
  return Array.from(found.values());
}

// ---------- 投稿ページ: アカウント名にホバーしてフォロワー数を読む ----------
// 実機検証済み: 投稿ページ最上部の非予約語プロフィールリンクにマウスイベントを疑似発生させると
// Instagram純正のプロフィールホバーカードが出て、本文に「1.1万\nフォロワー」のように現れる
async function captureFollowerViaHover() {
  const links = Array.from(document.querySelectorAll('a'))
    .filter((a) => {
      try {
        const seg = new URL(a.href).pathname.split('/').filter(Boolean);
        return seg.length === 1 && !RESERVED_PATH_SEGMENTS.has(seg[0]);
      } catch (e) { return false; }
    });
  const uniq = [...new Set(links)];
  const sorted = uniq.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
  const target = sorted[0];
  if (!target) return null;

  const username = target.getAttribute('href').replace(/\//g, '');
  const rect = target.getBoundingClientRect();
  const opts = { bubbles: true, cancelable: true, clientX: rect.x + rect.width / 2, clientY: rect.y + rect.height / 2, view: window };
  ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'mousemove'].forEach((type) => {
    target.dispatchEvent(new MouseEvent(type, opts));
  });

  // カード表示に時間がかかることがあるため、固定待機ではなく最大6秒ポーリングする。
  // ホバーが切れて閉じるのを防ぐため、待機中も定期的にmousemoveを再送する。
  let followerMatch = null;
  const deadline = Date.now() + 6000;
  while (Date.now() < deadline) {
    await sleep(600);
    followerMatch = parseFollowerMatch(document.body.innerText);
    if (followerMatch) break;
    target.dispatchEvent(new MouseEvent('mousemove', opts));
  }

  ['mousemove', 'mouseout', 'mouseleave', 'pointerout', 'pointerleave'].forEach((type) => {
    target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
  });

  if (!followerMatch) return { username, value: null };
  return { username, value: followerMatch.value, raw: followerMatch.raw };
}

// ---------- 投稿ページ: サムネイル・キャプションをog:タグから読む(ログイン済みなので成功率が高い) ----------
function cleanCaption(desc) {
  const m = desc.match(/:\s*"([\s\S]+)"\.?\s*$/);
  return m ? m[1].trim() : desc.trim();
}

function extractThumbnailAndCaption() {
  const imgMeta = document.querySelector('meta[property="og:image"]');
  const descMeta = document.querySelector('meta[property="og:description"]');
  const thumbnail = imgMeta ? (imgMeta.getAttribute('content') || '') : '';
  const rawDesc = descMeta ? (descMeta.getAttribute('content') || '') : '';
  const caption = rawDesc ? cleanCaption(rawDesc) : '';
  return { thumbnail, caption };
}

// ---------- バックフィル: プロフィールページ本文を直接読む(ホバー不要) ----------
function extractFollowerCountFromProfilePage() {
  const match = parseFollowerMatch(document.body.innerText);
  return match ? { value: match.value, raw: match.raw } : null;
}

// ---------- メイン ----------
async function main() {
  let activeCheck = { active: false };
  try {
    activeCheck = await chrome.runtime.sendMessage({ cmd: 'checkActive', path: location.pathname });
  } catch (e) { return; }

  if (!activeCheck.active) return;

  if (activeCheck.mode === 'discover' && activeCheck.phase === 'explore') {
    const { host, box } = createOverlay();
    box.innerHTML = `<div class="row">🔍 バズ動画をリサーチ中...</div>`;
    const candidates = await runExploreDiscovery(activeCheck.threshold, activeCheck.alreadyProcessed, activeCheck.maxAgeMonths);
    box.innerHTML = `<div class="row">✅ ${candidates.length}件の候補を発見（${activeCheck.threshold.toLocaleString()}再生以上）</div>`;
    removeOverlayLater(host, 3000);
    await chrome.runtime.sendMessage({ cmd: 'exploreCandidates', candidates });
    return;
  }

  if (activeCheck.mode === 'discover' && activeCheck.phase === 'post') {
    const shortcode = getShortcodeFromHref(location.pathname);
    if (!shortcode || shortcode !== activeCheck.current.shortcode) return;

    const { host, box } = createOverlay();
    box.innerHTML = `<div class="row">🔍 投稿者情報を確認中...</div>`;
    await sleep(randInt(1000, 2000));

    const result = await captureFollowerViaHover();
    const { thumbnail, caption } = extractThumbnailAndCaption();

    if (!result || result.value == null) {
      box.classList.add('anomaly');
      box.innerHTML = `
        <div class="row">⚠️ フォロワー数を検出できませんでした</div>
        <button id="buzz-skip" class="btn-secondary">スキップして次へ</button>
        <div class="row small" id="buzz-countdown">10秒後に自動スキップ</div>
      `;
      await chrome.runtime.sendMessage({ cmd: 'profileAnomaly', shortcode, reason: '検出失敗' });
      setupSkipButton(box, host, 10);
      return;
    }

    box.innerHTML = `
      <div class="row">✅ @${result.username}</div>
      <div class="row">👤 フォロワー: <b>${result.value.toLocaleString()}</b></div>
      <div class="row small">▶ 再生数: ${activeCheck.current.viewCount.toLocaleString()}（発見時点）</div>
      <div class="row small">${thumbnail ? '🖼 サムネイル取得済み ・ ' : '🖼 サムネイル未取得 ・ '}${caption ? '📝 キャプション取得済み' : '📝 キャプション未取得'}</div>
      <div class="row small">確認中…まもなく登録します</div>
    `;
    await sleep(randInt(1500, 3000));
    const res = await chrome.runtime.sendMessage({
      cmd: 'profileResult', shortcode, username: result.username, followerCount: result.value, thumbnail, caption,
    });
    box.innerHTML = res.ok
      ? `<div class="row">✅ アーカイブに登録しました</div>`
      : `<div class="row">❌ 登録失敗: ${res.error}</div>`;
    removeOverlayLater(host, res.ok ? 2500 : 6000);
    return;
  }

  if (activeCheck.mode === 'backfill' && activeCheck.queueType === 'profile') {
    const username = getUsernameFromProfileUrl(location.href);
    if (!username || username !== activeCheck.item.username) return;

    const { host, box } = createOverlay();
    box.innerHTML = `<div class="row">🔍 検出中...</div>`;
    await sleep(randInt(1500, 3000));

    const result = extractFollowerCountFromProfilePage();
    if (!result) {
      box.classList.add('anomaly');
      box.innerHTML = `
        <div class="row">⚠️ フォロワー数を検出できませんでした</div>
        <button id="buzz-skip" class="btn-secondary">スキップして次へ</button>
        <div class="row small" id="buzz-countdown">10秒後に自動スキップ</div>
      `;
      await chrome.runtime.sendMessage({ cmd: 'reportAnomaly', key: username, reason: '検出失敗' });
      setupSkipButton(box, host, 10);
      return;
    }

    box.innerHTML = `<div class="row">✅ フォロワー数: <b>${result.value.toLocaleString()}</b></div><div class="row small">確認中…まもなく自動送信します</div>`;
    await sleep(randInt(1500, 3000));
    const res = await chrome.runtime.sendMessage({ cmd: 'reportResult', username, value: result.value });
    box.innerHTML = res.ok ? `<div class="row">✅ 送信しました（${result.value.toLocaleString()}）</div>` : `<div class="row">❌ 送信失敗: ${res.error}</div>`;
    removeOverlayLater(host, res.ok ? 2500 : 6000);
  }
}

main().catch((e) => console.error('[buzz-stats-collector]', e));
